/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.pydroid.bootstrap.version

import com.pyamsoft.pydroid.bootstrap.version.update.AppUpdateLauncher
import com.pyamsoft.pydroid.bootstrap.version.update.AppUpdater
import com.pyamsoft.pydroid.core.LintIgnoreTooGenericExceptionCaught
import com.pyamsoft.pydroid.util.AppDispatchers
import com.pyamsoft.pydroid.util.Logger
import com.pyamsoft.pydroid.util.ResultWrapper
import com.pyamsoft.pydroid.util.ifNotCancellation
import kotlinx.coroutines.withContext

internal class VersionInteractorNetwork
internal constructor(
    private val updater: AppUpdater,
    private val dispatchers: AppDispatchers,
) : VersionInteractor {

  override suspend fun watchDownloadStatus(
      onDownloadProgress: (Float) -> Unit,
      onDownloadCompleted: () -> Unit,
      onDownloadCancelled: () -> Unit,
      onDownloadFailed: () -> Unit,
  ) =
      withContext(context = dispatchers.default) {
        updater.watchDownloadStatus(
            onDownloadProgress = onDownloadProgress,
            onDownloadCompleted = onDownloadCompleted,
            onDownloadCancelled = onDownloadCancelled,
            onDownloadFailed = onDownloadFailed,
        )
      }

  override suspend fun completeUpdate() =
      withContext(context = dispatchers.default) {
        Logger.d { "GOING DOWN FOR UPDATE" }
        updater.completeUpgrade()
      }

  override suspend fun checkVersion(): ResultWrapper<AppUpdateLauncher> =
      withContext(context = dispatchers.default) {
        return@withContext try {
          ResultWrapper.success(updater.checkForUpdate())
        } catch (@LintIgnoreTooGenericExceptionCaught e: Throwable,) {
          e.ifNotCancellation {
            Logger.e(e) { "Failed to check for updates" }
            ResultWrapper.failure(e)
          }
        }
      }
}
