/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.pydroid.ui.app

import androidx.activity.ComponentActivity
import androidx.annotation.CheckResult
import com.pyamsoft.pydroid.ui.changelog.ChangeLogProvider
import com.pyamsoft.pydroid.ui.internal.pydroid.ObjectGraph
import com.pyamsoft.pydroid.ui.internal.pydroid.PYDroidActivityDelegateInternal

@CheckResult
private fun createPYDroidDelegate(
    activity: ComponentActivity,
    provider: ChangeLogProvider,
): PYDroidActivityDelegateInternal {
  val component =
      ObjectGraph.ApplicationScope.retrieve(activity.application).injector().plusApp().create()
  return PYDroidActivityDelegateInternal(component, provider, activity)
}

/**
 * Install PYDroid into an Activity
 *
 * Returns a delegate that can optionally be saved or used in the calling Activity level to handle
 * common functions like checking for updates or showing an in-app review dialog
 */
public fun ComponentActivity.installPYDroid(
    provider: ChangeLogProvider,
): PYDroidActivityDelegate {
  val self = this
  val internals = createPYDroidDelegate(self, provider)
  ObjectGraph.ActivityScope.install(self, internals)
  return internals
}
