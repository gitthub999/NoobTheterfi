/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.pydroid.ui.internal.version

import androidx.annotation.CheckResult
import com.pyamsoft.pydroid.bootstrap.version.VersionModule
import com.pyamsoft.pydroid.ui.version.VersionUpgradeAvailable
import com.pyamsoft.pydroid.util.AppDispatchers

internal interface VersionCheckComponent {

  fun inject(component: VersionUpgradeAvailable)

  interface Factory {

    @CheckResult fun create(): VersionCheckComponent

    @ConsistentCopyVisibility
    data class Parameters
    internal constructor(
        internal val module: VersionModule,
        internal val state: MutableVersionCheckViewState,
        internal val dispatchers: AppDispatchers,
    )
  }

  class Impl
  private constructor(
      private val params: Factory.Parameters,
  ) : VersionCheckComponent {

    override fun inject(component: VersionUpgradeAvailable) {
      component.viewModel =
          VersionCheckViewModeler(
              state = params.state,
              interactor = params.module.provideInteractor(),
              dispatchers = params.dispatchers,
          )
    }

    internal class FactoryImpl
    internal constructor(
        private val params: Factory.Parameters,
    ) : Factory {

      override fun create(): VersionCheckComponent {
        return Impl(params)
      }
    }
  }
}
