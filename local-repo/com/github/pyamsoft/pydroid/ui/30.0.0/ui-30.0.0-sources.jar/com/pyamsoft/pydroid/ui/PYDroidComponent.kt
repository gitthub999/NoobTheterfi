/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.pydroid.ui

import android.app.Application
import android.content.Context
import androidx.annotation.CheckResult
import coil3.ImageLoader
import com.pyamsoft.pydroid.billing.BillingMode
import com.pyamsoft.pydroid.billing.BillingModule
import com.pyamsoft.pydroid.bootstrap.about.AboutModule
import com.pyamsoft.pydroid.bootstrap.changelog.ChangeLogModule
import com.pyamsoft.pydroid.bootstrap.datapolicy.DataPolicyModule
import com.pyamsoft.pydroid.bootstrap.rating.RatingModule
import com.pyamsoft.pydroid.bootstrap.settings.SettingsModule
import com.pyamsoft.pydroid.bootstrap.version.VersionModule
import com.pyamsoft.pydroid.bus.EventBus
import com.pyamsoft.pydroid.core.ThreadEnforcer
import com.pyamsoft.pydroid.core.createThreadEnforcer
import com.pyamsoft.pydroid.ui.debug.InAppDebugStatus
import com.pyamsoft.pydroid.ui.internal.about.AboutComponent
import com.pyamsoft.pydroid.ui.internal.app.AppComponent
import com.pyamsoft.pydroid.ui.internal.datapolicy.dialog.DataPolicyDialogComponent
import com.pyamsoft.pydroid.ui.internal.debug.DebugInteractorImpl
import com.pyamsoft.pydroid.ui.internal.debug.InAppDebugLogLine
import com.pyamsoft.pydroid.ui.internal.debug.InAppDebugLoggerImpl
import com.pyamsoft.pydroid.ui.internal.haptics.AndroidViewHapticManager
import com.pyamsoft.pydroid.ui.internal.preference.PYDroidPreferencesImpl
import com.pyamsoft.pydroid.ui.internal.settings.reset.ResetComponent
import com.pyamsoft.pydroid.ui.internal.theme.ThemingImpl
import com.pyamsoft.pydroid.ui.theme.Theming
import com.pyamsoft.pydroid.util.AppDispatchers
import com.pyamsoft.pydroid.util.Logger
import com.pyamsoft.pydroid.util.PYDroidLogger
import com.pyamsoft.pydroid.util.isDebugMode
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

internal interface PYDroidComponent {

  @CheckResult fun plusApp(): AppComponent.Factory

  @CheckResult fun plusAbout(): AboutComponent.Factory

  @CheckResult fun plusDataPolicyDialog(): DataPolicyDialogComponent.Factory

  @CheckResult fun plusReset(): ResetComponent.Factory

  fun inject(logger: InAppDebugLoggerImpl)

  fun inject(hapticManager: AndroidViewHapticManager)

  interface Factory {

    @CheckResult fun create(params: Component.Parameters): Component
  }

  interface Component : PYDroidComponent {

    @CheckResult fun moduleProvider(): ModuleProvider

    @ConsistentCopyVisibility
    data class Parameters
    internal constructor(
        internal val application: Application,
        override val privacyPolicyUrl: String,
        override val bugReportUrl: String,
        override val viewSourceUrl: String,
        override val termsConditionsUrl: String,
        override val version: Int,
        override val logger: PYDroidLogger?,
        override val dispatchers: AppDispatchers,
        override val billing: (params: BillingModule.Parameters) -> BillingModule,
        override val rating: (params: RatingModule.Parameters) -> RatingModule,
        override val versionCheck: (params: VersionModule.Parameters) -> VersionModule,
        override val billingMode: BillingMode,
    ) : PYDroid.InternalParameters
  }

  class ComponentImpl
  private constructor(
      params: Component.Parameters,
  ) : Component {

    private val enforcer = createThreadEnforcer(params.application.isDebugMode())

    private val context: Context = params.application

    private val imageLoader: ImageLoader by lazy { ImageLoader(params.application) }

    private val theming: Theming by lazy { ThemingImpl(preferences, params.dispatchers) }

    private val isDebugMode by lazy { context.isDebugMode() }

    private val preferences by lazy {
      PYDroidPreferencesImpl(
          context = params.application,
          versionCode = params.version,
          dispatchers = params.dispatchers,
      )
    }

    private val inAppLogLines by lazy { MutableStateFlow(emptyList<InAppDebugLogLine>()) }

    private val debugInteractor by lazy {
      DebugInteractorImpl(
          enforcer = enforcer,
          dispatchers = params.dispatchers,
          context = params.application,
      )
    }

    private val aboutModule by lazy {
      AboutModule(
          params =
              AboutModule.Parameters(
                  context = context,
                  dispatchers = params.dispatchers,
              ),
      )
    }

    private val dataPolicyModule by lazy {
      DataPolicyModule(
          params =
              DataPolicyModule.Parameters(
                  context = context,
                  preferences = preferences,
                  dispatchers = params.dispatchers,
              ),
      )
    }

    private val changeLogModule by lazy {
      ChangeLogModule(
          params =
              ChangeLogModule.Parameters(
                  context = context,
                  preferences = preferences,
                  dispatchers = params.dispatchers,
                  isFakeChangeLogAvailable =
                      if (isDebugMode) preferences.listenShowChangelogUpsell() else null,
              ),
      )
    }

    private val appParams by lazy {
      AppComponent.Factory.Parameters(
          isDebugMode = isDebugMode,
          enforcer = enforcer,
          context = context,
          theming = theming,
          billingErrorBus = EventBus.create(),
          billingPurchaseBus = EventBus.create(),
          changeLogModule = changeLogModule,
          imageLoader = imageLoader,
          version = params.version,
          dataPolicyModule = dataPolicyModule,
          bugReportUrl = params.bugReportUrl,
          termsConditionsUrl = params.termsConditionsUrl,
          privacyPolicyUrl = params.privacyPolicyUrl,
          viewSourceUrl = params.viewSourceUrl,
          billingPreferences = preferences,
          debugPreferences = preferences,
          logLinesBus = inAppLogLines,
          debugInteractor = debugInteractor,
          hapticPreferences = preferences,
          dispatchers = params.dispatchers,
          billing = params.billing,
          rating = params.rating,
          versionCheck = params.versionCheck,
          billingMode = params.billingMode,
      )
    }

    private val aboutParams by lazy {
      AboutComponent.Factory.Parameters(
          module = aboutModule,
          dispatchers = params.dispatchers,
      )
    }

    private val dataPolicyParams by lazy {
      DataPolicyDialogComponent.Factory.Parameters(
          imageLoader = imageLoader,
          module = dataPolicyModule,
          dispatchers = params.dispatchers,
          privacyPolicyUrl = params.privacyPolicyUrl,
          termsConditionsUrl = params.termsConditionsUrl,
      )
    }

    private val resetParams by lazy {
      ResetComponent.Factory.Parameters(
          dispatchers = params.dispatchers,
          module =
              SettingsModule(
                  params =
                      SettingsModule.Parameters(
                          context = context,
                      ),
              ),
      )
    }

    private val provider by lazy {
      object : ModuleProvider {

        private val modules by lazy {
          object : ModuleProvider.Modules {

            override fun imageLoader(): ImageLoader {
              return imageLoader
            }

            override fun theming(): Theming {
              return theming
            }

            override fun enforcer(): ThreadEnforcer {
              return enforcer
            }

            override fun inAppDebugStatus(): InAppDebugStatus {
              return preferences
            }

            override fun dispatchers(): AppDispatchers {
              return params.dispatchers
            }
          }
        }

        override fun get(): ModuleProvider.Modules {
          return modules
        }
      }
    }

    init {
      params.logger?.also { Logger.setLogger(it) }
      MainScope().launch(context = params.dispatchers.default) { theming.init() }
    }

    override fun plusApp(): AppComponent.Factory {
      return AppComponent.Impl.FactoryImpl(appParams)
    }

    override fun plusAbout(): AboutComponent.Factory {
      return AboutComponent.Impl.FactoryImpl(aboutParams)
    }

    override fun plusDataPolicyDialog(): DataPolicyDialogComponent.Factory {
      return DataPolicyDialogComponent.Impl.FactoryImpl(dataPolicyParams)
    }

    override fun plusReset(): ResetComponent.Factory {
      return ResetComponent.Impl.FactoryImpl(resetParams)
    }

    override fun moduleProvider(): ModuleProvider {
      return provider
    }

    override fun inject(logger: InAppDebugLoggerImpl) {
      logger.logLines = inAppLogLines
      logger.status = preferences
    }

    override fun inject(hapticManager: AndroidViewHapticManager) {
      hapticManager.preferences = preferences
    }

    class FactoryImpl internal constructor() : Factory {

      override fun create(params: Component.Parameters): Component {
        return ComponentImpl(params)
      }
    }
  }
}
