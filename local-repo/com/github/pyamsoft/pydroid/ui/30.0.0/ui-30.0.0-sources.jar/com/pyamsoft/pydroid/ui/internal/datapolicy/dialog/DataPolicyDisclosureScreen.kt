/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.pydroid.ui.internal.datapolicy.dialog

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.ImageLoader
import com.pyamsoft.pydroid.theme.keylines
import com.pyamsoft.pydroid.ui.R
import com.pyamsoft.pydroid.ui.haptics.LocalHapticManager
import com.pyamsoft.pydroid.ui.internal.app.AppHeader
import com.pyamsoft.pydroid.ui.internal.test.createNewTestImageLoader
import com.pyamsoft.pydroid.ui.uri.rememberUriHandler

private enum class DataPolicyDisclosureScreenItems {
  DISCLOSURE,
}

@Composable
internal fun DataPolicyDisclosureScreen(
    modifier: Modifier = Modifier,
    state: DataPolicyDialogViewState,
    imageLoader: ImageLoader,
    onNavigationErrorDismissed: () -> Unit,
    onAccept: () -> Unit,
    onReject: () -> Unit,
) {
  val snackbarHostState = remember { SnackbarHostState() }
  val icon by state.icon.collectAsStateWithLifecycle()
  val name by state.name.collectAsStateWithLifecycle()
  val navigationError by state.navigationError.collectAsStateWithLifecycle()

  val tosUrl by state.tosUrl.collectAsStateWithLifecycle()
  val privacyPolicyUrl by state.privacyPolicyUrl.collectAsStateWithLifecycle()

  AppHeader(
      modifier = modifier,
      icon = icon,
      name = name,
      imageLoader = imageLoader,
      afterScroll = {
        NavigationError(
            modifier = Modifier.fillMaxWidth(),
            snackbarHostState = snackbarHostState,
            error = navigationError,
            onSnackbarDismissed = onNavigationErrorDismissed,
        )

        Actions(
            modifier = Modifier.fillMaxWidth(),
            appName = name,
            tosUrl = tosUrl,
            privacyPolicyUrl = privacyPolicyUrl,
            onAccept = onAccept,
            onReject = onReject,
        )
      },
  ) {
    item(
        contentType = DataPolicyDisclosureScreenItems.DISCLOSURE,
    ) {
      Disclosure(
          modifier = Modifier.fillMaxWidth(),
          appName = name,
      )
    }
  }
}

@Composable
private fun renderAcceptTerms(
    appName: String,
    tosUrl: String,
    privacyPolicyUrl: String,
): AnnotatedString {
  val uriHandler = rememberUriHandler()
  val handleLinkClicked by rememberUpdatedState { link: LinkAnnotation ->
    if (link is LinkAnnotation.Url) {
      uriHandler.openUri(link.url)
    }
  }

  val linkColor = MaterialTheme.colorScheme.primary
  val tosText = stringResource(R.string.terms_conditions)
  val privacyText = stringResource(R.string.privacy_policy)

  val rawBlurb = stringResource(R.string.disclosure_accepted, appName, tosText, privacyText)

  return remember(
      linkColor,
      rawBlurb,
      tosText,
      privacyText,
  ) {
    val tosIndex = rawBlurb.indexOf(tosText)
    val privacyIndex = rawBlurb.indexOf(privacyText)

    val linkStyle =
        SpanStyle(
            color = linkColor,
            textDecoration = TextDecoration.Underline,
        )

    val spanStyles =
        listOf(
            AnnotatedString.Range(
                linkStyle,
                start = tosIndex,
                end = tosIndex + tosText.length,
            ),
            AnnotatedString.Range(
                linkStyle,
                start = privacyIndex,
                end = privacyIndex + privacyText.length,
            ),
        )

    val visualString =
        AnnotatedString(
            rawBlurb,
            spanStyles = spanStyles,
        )

    // Can only add annotations to builders
    return@remember AnnotatedString.Builder(visualString)
        .apply {
          // TOS clickable
          addLink(
              url =
                  LinkAnnotation.Url(
                      url = tosUrl,
                      linkInteractionListener = { handleLinkClicked(it) },
                  ),
              start = tosIndex,
              end = tosIndex + tosText.length,
          )

          // Privacy clickable
          addLink(
              url =
                  LinkAnnotation.Url(
                      url = privacyPolicyUrl,
                      linkInteractionListener = { handleLinkClicked(it) },
                  ),
              start = privacyIndex,
              end = privacyIndex + privacyText.length,
          )
        }
        .toAnnotatedString()
  }
}

@Composable
private fun Disclosure(
    modifier: Modifier = Modifier,
    appName: String,
) {
  val disclosureStyle =
      MaterialTheme.typography.bodyMedium.copy(
          color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

  Column(
      modifier = modifier.padding(MaterialTheme.keylines.content),
  ) {
    Text(
        text = stringResource(R.string.disclosure_title, appName),
        style = MaterialTheme.typography.bodyLarge,
    )

    Text(
        modifier = Modifier.padding(top = MaterialTheme.keylines.content),
        style = disclosureStyle,
        text = stringResource(R.string.disclosure_start).trimIndent().replace("\n", " "),
    )

    Text(
        modifier = Modifier.padding(top = MaterialTheme.keylines.content),
        style = disclosureStyle,
        text = stringResource(R.string.disclosure_end, appName).trimIndent().replace("\n", " "),
    )
  }
}

@Composable
private fun Actions(
    modifier: Modifier = Modifier,
    appName: String,
    tosUrl: String,
    privacyPolicyUrl: String,
    onAccept: () -> Unit,
    onReject: () -> Unit,
) {
  val hapticManager = LocalHapticManager.current

  Column(
      modifier =
          modifier
              .padding(horizontal = MaterialTheme.keylines.content)
              .padding(bottom = MaterialTheme.keylines.baseline),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
  ) {
    Text(
        modifier = Modifier.fillMaxWidth().padding(vertical = MaterialTheme.keylines.baseline),
        style =
            MaterialTheme.typography.labelSmall.copy(
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            ),
        textAlign = TextAlign.Center,
        text =
            renderAcceptTerms(
                appName = appName,
                tosUrl = tosUrl,
                privacyPolicyUrl = privacyPolicyUrl,
            ),
    )

    Button(
        onClick = {
          hapticManager?.confirmButtonPress()
          onAccept()
        },
    ) {
      Text(
          text = stringResource(R.string.dpd_accept),
          style = MaterialTheme.typography.labelMedium,
      )
    }
    TextButton(
        onClick = {
          hapticManager?.cancelButtonPress()
          onReject()
        },
    ) {
      Text(
          text = stringResource(R.string.dpd_reject),
          style = MaterialTheme.typography.labelSmall,
      )
    }
  }
}

@Composable
private fun NavigationError(
    modifier: Modifier = Modifier,
    snackbarHostState: SnackbarHostState,
    error: Throwable?,
    onSnackbarDismissed: () -> Unit,
) {
  if (error != null) {
    LaunchedEffect(error) {
      snackbarHostState.showSnackbar(
          message = error.message ?: "An unexpected error occurred",
          duration = SnackbarDuration.Long,
      )

      // We ignore the showSnackbar result because we don't care (no actions)
      onSnackbarDismissed()
    }
  }

  SnackbarHost(
      modifier = modifier,
      hostState = snackbarHostState,
  )
}

@Preview
@Composable
private fun PreviewDataPolicyDisclosureScreen() {
  DataPolicyDisclosureScreen(
      state =
          MutableDataPolicyDialogViewState(
                  tosUrl = "",
                  privacyPolicyUrl = "",
              )
              .apply {
                icon.value = 0
                name.value = "TEST"
                navigationError.value = null
              },
      imageLoader = createNewTestImageLoader(),
      onNavigationErrorDismissed = {},
      onAccept = {},
      onReject = {},
  )
}
