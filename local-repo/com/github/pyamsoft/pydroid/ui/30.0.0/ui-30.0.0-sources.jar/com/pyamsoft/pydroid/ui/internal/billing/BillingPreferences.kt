/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.pydroid.ui.internal.billing

import androidx.annotation.CheckResult
import kotlinx.coroutines.flow.Flow

/** Preferences for billing */
internal interface BillingPreferences {

  /** Should we show a Billing upsell */
  @CheckResult fun listenForBillingUpsellChanges(): Flow<Boolean>

  /** Show the upsell if we have hit the "minimum" shown count */
  fun maybeShowBillingUpsell()

  /** Reset the billing upsell once it is shown */
  fun resetBillingShown()

  /** Listen for changes to the billing upsell disabled preference */
  @CheckResult fun listenForBillingUpsellDisabledChanges(): Flow<Boolean>

  /** Set whether the billing upsell is disabled */
  fun setBillingUpsellDisabled(disabled: Boolean)
}
