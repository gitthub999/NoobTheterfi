/*
 * Copyright 2026 pyamsoft
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pyamsoft.pydroid.ui.internal.settings.version

import androidx.annotation.CheckResult
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import com.pyamsoft.pydroid.ui.version.VersionCheckViewState.CheckingState

@Stable
@Immutable
@ConsistentCopyVisibility
internal data class VersionCheckingSettingsState
internal constructor(
    val isChecking: CheckingState,
    val isEmptyUpdate: Boolean,
    val newVersion: Int,
) {
  companion object {
    @JvmStatic
    @CheckResult
    fun empty(): VersionCheckingSettingsState {
      return VersionCheckingSettingsState(
          isChecking = CheckingState.None,
          isEmptyUpdate = false,
          newVersion = 0,
      )
    }
  }
}
